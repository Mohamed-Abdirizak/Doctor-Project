import 'dart:ffi';

import 'package:doctorproject/home.dart';
import 'package:flutter/material.dart';

import 'onewdigetforseealldoctors.dart';

class seeAllDoctors extends StatelessWidget {
  const seeAllDoctors({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          children: [
            Column(
              children: [
                Container(
                  margin: EdgeInsets.all(30),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      GestureDetector(
                        onTap: () => Navigator.push(context,
                            MaterialPageRoute(builder: (context) => Home())),
                        child: Icon(
                          Icons.arrow_back_ios,
                          size: 40,
                        ),
                      ),
                      Text(
                        "Dhaqaatiirta ugu caansan",
                        style: TextStyle(fontSize: 25),
                      ),
                      Icon(
                        Icons.more_vert,
                        size: 40,
                      )
                    ],
                  ),
                ),

                oneWidgetForSeeAllDoctors(
                    image: "lib/images/g1doctor.png",
                    docName: "Batuulo Xasan ",
                    docRate: "4.8",
                    docTaqasus: "Cudurada Wadnaha",
                    docLocation: "Muqdisho"),

                oneWidgetForSeeAllDoctors(
                    image: "lib/images/m1doctor.png",
                    docName: "Xasan Mohamed",
                    docRate: "4.7",
                    docTaqasus: "Cudurada Guud",
                    docLocation: "Muqdisho"),

                oneWidgetForSeeAllDoctors(
                    image: "lib/images/g2doctor.png",
                    docName: "Xaliimo Xaashi",
                    docRate: "4.9",
                    docTaqasus: "Cudurada Haweenka",
                    docLocation: "Muqdisho"),

                oneWidgetForSeeAllDoctors(
                    image: "lib/images/m2doctor.png",
                    docName: "Abdirizak Cali",
                    docRate: "5.0",
                    docTaqasus: "Cudurada Burada",
                    docLocation: "Muqdisho"),

                oneWidgetForSeeAllDoctors(
                    image: "lib/images/g3doctor.png",
                    docName: "Raho Cali",
                    docRate: "3.6",
                    docTaqasus: "Cudurada Caloosha",
                    docLocation: "Muqdisho"),

                oneWidgetForSeeAllDoctors(
                    image: "lib/images/m3doctor.png",
                    docName: "Batar Salaad",
                    docRate: "2.3",
                    docTaqasus: "Cudurada Maskaxda",
                    docLocation: "Muqdisho"),

                oneWidgetForSeeAllDoctors(
                    image: "lib/images/g4doctor.png",
                    docName: "Zamzam Caalim",
                    docRate: "1.6",
                    docTaqasus: "Cudurada Haweenka",
                    docLocation: "Muqdisho"),

                oneWidgetForSeeAllDoctors(
                    image: "lib/images/m4doctor.png",
                    docName: "Fatih Jimale",
                    docRate: "1.6",
                    docTaqasus: "Cudurada Guud",
                    docLocation: "Muqdisho"),

                // Container(
                //   margin: EdgeInsets.all(20),
                //   padding: EdgeInsets.only(
                //     left: 20,
                //     top: 20,
                //     right: 20,
                //   ),
                //   decoration: BoxDecoration(
                //       color: Colors.grey[200],
                //       borderRadius: BorderRadius.circular(50)),
                //   child: Row(children: [
                //     Image.asset(
                //       "lib/images/m2doctor.png",
                //       height: 200,
                //       width: 200,
                //     ),
                //     Column(
                //       crossAxisAlignment: CrossAxisAlignment.start,
                //       children: [
                //         Text(
                //           "Fatih Jimale",
                //           style: TextStyle(fontSize: 30),
                //         ),
                //         SizedBox(
                //           height: 10,
                //         ),
                //         Text(
                //           "Chardiologist",
                //           style:
                //               TextStyle(fontSize: 20, color: Colors.grey[600]),
                //         ),
                //         SizedBox(
                //           height: 10,
                //         ),
                //         Row(
                //           children: [
                //             Icon(
                //               Icons.star,
                //               color: Colors.orange,
                //               size: 30,
                //             ),
                //             SizedBox(
                //               width: 10,
                //             ),
                //             Text(
                //               "4.7",
                //               style:
                //                   TextStyle(color: Colors.orange, fontSize: 20),
                //             )
                //           ],
                //         ),
                //         SizedBox(
                //           height: 10,
                //         ),
                //         Row(
                //           children: [
                //             Icon(
                //               Icons.location_on,
                //               color: Colors.grey,
                //               size: 30,
                //             ),
                //             Text(
                //               "Muqdisho",
                //               style:
                //                   TextStyle(color: Colors.grey, fontSize: 20),
                //             )
                //           ],
                //         ),
                //       ],
                //     ),
                //   ]),
                // )
              ],
            ),
          ],
        ),
      ),
    );
  }
}
