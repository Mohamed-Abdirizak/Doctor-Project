import 'package:doctorproject/firstPageDoctors.dart';
import 'package:doctorproject/onewdigetforseealldoctors.dart';
import 'package:doctorproject/seeallDoctors.dart';
import 'package:doctorproject/smallfour.dart';
import 'package:flutter/material.dart';

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          children: [
            Container(
              margin: EdgeInsets.only(top: 40, left: 30, right: 30),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                // crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "hel dhaqtar leh",
                    style: TextStyle(fontSize: 35),
                  ),
                  Icon(
                    Icons.notifications_outlined,
                    size: 40,
                  )
                ],
              ),
            ),
            // inta waxaa kabilabanaayo text("health solutions..")
            Container(
              margin: EdgeInsets.only(left: 30),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "aqoon kufilan",
                    style: TextStyle(fontSize: 35),
                  )
                ],
              ),
            ),
            //            // inta waxaa ku eg text("health solutions..")
            SizedBox(
              height: 30,
            ),

            /// serach fake ah starts here..
            Container(
              padding: EdgeInsets.all(15),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey),
              ),
              margin: EdgeInsets.only(left: 30, right: 30),
              child: TextField(
                decoration: InputDecoration(
                    border: InputBorder.none,
                    prefixIcon: Icon(Icons.search),
                    hintText: "Raadi Dhakhaatiirta, Daawooyinka, maqaallada"),

                // child: Row(
                // children: [
                // Icon(
                //   Icons.search,
                //   size: 30,
                //   color: Colors.grey,
                // ),
                // SizedBox(
                //   width: 10,
                // ),
                // Text(
                //   "Search doctors, drugs, articles",
                //   style: TextStyle(fontSize: 20, color: Colors.grey),
                // )
                // ],
                // ),
              ),
            ),
            // search fake ah ends here..

            SizedBox(
              height: 30,
            ),

            /// little four job..
            Container(
              margin: EdgeInsets.all(30),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  smallFour(
                      image: 'lib/images/doctor.png', textHoos: "Dhaqtar"),
                  smallFour(
                      image: 'lib/images/drugs.png', textHoos: "Pharmacy"),
                  smallFour(
                      image: 'lib/images/hospital.png', textHoos: "Isbitaal"),
                  smallFour(
                      image: 'lib/images/ambulance.png', textHoos: "Ambulance"),
                ],
              ),
            ), // ends here..

/////// starts here: the blue bg that contains: doctor girl , texts and button.
            Column(
              children: [
                Container(
                  margin: EdgeInsets.only(left: 30, right: 30),
                  padding: EdgeInsets.only(top: 20, right: 20, left: 20),
                  decoration: BoxDecoration(
                      color: Colors.blue[300],
                      borderRadius: BorderRadius.circular(15)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Adiga iyo qoyskaagabo",
                            style: TextStyle(fontSize: 25, color: Colors.white),
                          ),
                          Text(
                            "sameeya kahortag",
                            style: TextStyle(fontSize: 25, color: Colors.white),
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          Container(
                              padding: EdgeInsets.only(
                                  top: 10, bottom: 10, left: 30, right: 30),
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(12)),
                              child: Text(
                                "Xog badan ogaaw...",
                                style:
                                    TextStyle(fontSize: 20, color: Colors.blue),
                              ))
                        ],
                      ),
                      Image.asset(
                        "lib/images/wdoctor.png",
                        height: 150,
                        width: 150,
                      )
                    ],
                  ),
                ),
              ],
            ),

            /// ends here: the blue bg that contains: doctor girl , texts and button.
            ///
            SizedBox(
              height: 30,
            ),

            /// this row starts here: contains two texts: top doctor and see all..
            Container(
              margin: EdgeInsets.only(left: 30, right: 30),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Dhaqaatiirta ugu caansan",
                    style: TextStyle(
                      fontSize: 20,
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => seeAllDoctors()));
                    },
                    child: Text(
                      "dhamaan arag",
                      style: TextStyle(fontSize: 20, color: Colors.blue),
                    ),
                  )
                ],
              ),
            ),

            /// this row ends here: contains two texts: top doctor and see all..
            ///
            SizedBox(
              height: 20,
            ),
            Container(
              margin: EdgeInsets.all(20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  firstPageDoctors(
                      rateNo: "4.6",
                      image: 'lib/images/m1doctor.png',
                      docName: "Fatih Jimale ",
                      docXirfad: "Dhaqtarak Caruurta",
                      doLocation: "Muqdisho"),
                  firstPageDoctors(
                      rateNo: "4.5",
                      image: "lib/images/g1doctor.png",
                      docName: "Sasha Alia Hirsi",
                      docXirfad: "Dhaqtarka Killiyaha",
                      doLocation: "Muqdisho")
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.all(20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  firstPageDoctors(
                      rateNo: "4.8",
                      image: "lib/images/m2doctor.png",
                      docName: "Hassan Cali",
                      docXirfad: "Dhaqtarka Uurkujirta",
                      doLocation: "Muqdisho"),
                  firstPageDoctors(
                      rateNo: "4.9",
                      image: "lib/images/g2doctor.png",
                      docName: "Xaliimo Hirsi",
                      docXirfad: "Dhaqtarka Dhalmada",
                      doLocation: "Muqdisho")
                ],
              ),
            ),
            // Container(
            //   margin: EdgeInsets.all(20),
            //   child: Row(
            //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //     children: [
            //       firstPageDoctors(
            //           rateNo: "4.0",
            //           image: "lib/images/m3doctor.png",
            //           docName: "Abuukara cali",
            //           docXirfad: "Dhaqtarka wadnaha",
            //           doLocation: "Muqdisho"),
            //       firstPageDoctors(
            //           rateNo: "4.9",
            //           image: "lib/images/g2doctor.png",
            //           docName: "Xaliimo Hirsi",
            //           docXirfad: "Dhaqtarka Dhalmada",
            //           doLocation: "Muqdisho")
            //     ],
            //   ),
            // ),

            // Container(
            //   margin: EdgeInsets.all(20),
            //   child: Row(
            //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //     children: [
            //       firstPageDoctors(
            //           rateNo: "4.7",
            //           image: "lib/images/m4doctor.png",
            //           docName: "Xasan Cali",
            //           docXirfad: "Dhaqtarka Burada",
            //           doLocation: "Muqdisho"),
            //       firstPageDoctors(
            //           rateNo: "4.1",
            //           image: "lib/images/g3doctor.png",
            //           docName: "Sundus Cali",
            //           docXirfad: "Dhaqtarka Caruurta",
            //           doLocation: "Muqdisho")
            //     ],
            //   ),
            // )
          ],
        ),
      ),
    );
  }
}
