import 'package:flutter/material.dart';

class oneWidgetForSeeAllDoctors extends StatelessWidget {
  final image;
  final String docName;
  final String docTaqasus;
  final String docRate;
  final String docLocation;
  const oneWidgetForSeeAllDoctors(
      {super.key,
      required this.image,
      required this.docName,
      required this.docRate,
      required this.docTaqasus,
      required this.docLocation});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(20),
      padding: EdgeInsets.only(
        left: 20,
        top: 20,
        right: 20,
      ),
      decoration: BoxDecoration(
          color: Colors.grey[200], borderRadius: BorderRadius.circular(50)),
      child: Row(children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Image.asset(
            this.image,
            height: 200,
            width: 200,
          ),
        ),
        SizedBox(
          width: 20,
        ),
        Column(
          /// the column of docname, doctaqasus, docrate, docloation starts here....
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              this.docName,
              style: TextStyle(fontSize: 30),
            ),
            SizedBox(
              height: 10,
            ),
            Text(
              this.docTaqasus,
              style: TextStyle(fontSize: 20, color: Colors.grey[600]),
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              children: [
                Icon(
                  Icons.star,
                  color: Colors.orange,
                  size: 30,
                ),
                SizedBox(
                  width: 10,
                ),
                Text(
                  "4.7",
                  style: TextStyle(color: Colors.orange, fontSize: 20),
                )
              ],
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              children: [
                Icon(
                  Icons.location_on,
                  color: Colors.grey,
                  size: 30,
                ),
                Text(
                  this.docLocation,
                  style: TextStyle(color: Colors.grey, fontSize: 20),
                )
              ],
            ),
          ],
        ),
      ]),
    );
  }
}
