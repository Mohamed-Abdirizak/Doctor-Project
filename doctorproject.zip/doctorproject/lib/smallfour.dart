import 'package:flutter/material.dart';

class smallFour extends StatelessWidget {
  final image;
  final String textHoos;
  const smallFour({super.key, required this.image, required this.textHoos});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: EdgeInsets.all(20),
          decoration: BoxDecoration(
              color: Colors.blue[100], borderRadius: BorderRadius.circular(12)),
          child: Image.asset(
            this.image,
            height: 60,
            width: 60,
          ),
        ),
        SizedBox(
          height: 10,
        ),
        Container(
            // margin: EdgeInsets.only(left: 60),
            child: Text(
          this.textHoos,
          style: TextStyle(fontSize: 20, color: Colors.grey),
        ))
      ],
    );
  }
}
