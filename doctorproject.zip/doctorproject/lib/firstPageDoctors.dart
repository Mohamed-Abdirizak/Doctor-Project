import 'package:flutter/material.dart';

class firstPageDoctors extends StatelessWidget {
  final String rateNo;
  final image;
  final String docName;
  final String docXirfad;
  final String doLocation;

  const firstPageDoctors(
      {super.key,
      required this.rateNo,
      required this.image,
      required this.docName,
      required this.docXirfad,
      required this.doLocation});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(30),
      decoration: BoxDecoration(
          border: Border.all(color: Colors.grey),
          borderRadius: BorderRadius.circular(20)),
      // margin: EdgeInsets.all(10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Row(
            // start: the first row: contains star icon and rating text..
            children: [
              Icon(
                Icons.star,
                color: Colors.orange,
                size: 30,
              ),
              Text(
                this.rateNo,
                style: TextStyle(fontSize: 20, color: Colors.orange),
              )
            ],
          ),

          /// the end row: contains star icon and rating text..
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Image.asset(
                this.image,
                height: 150,
                width: 150,
              ),
              SizedBox(
                height: 10,
              ),
              Text(
                this.docName,
                style: TextStyle(fontSize: 25),
              ),
              Text(
                this.docXirfad,
                style: TextStyle(fontSize: 20, color: Colors.grey),
              ),
              Row(
                children: [
                  Icon(
                    Icons.location_on,
                    color: Colors.grey,
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Text(
                    this.doLocation,
                    style: TextStyle(color: Colors.grey),
                  )
                ],
              ),
            ],
          )
        ],
      ),
    );
  }
}
